#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Megan J Hurt, 8/13/18, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all to do items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove an existing item from the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add each dictionary "row" to a python list "table"
print("Opening To Do list . . .\n")
toDo_file = open(objFileName,'r')
for row in toDo_file:                   # load each "row" of data from Todo.txt into dicRow
    task,priority = row.strip().split(',')
    dicRow[task] = priority

for row in dicRow.items():              # add each dictionary row to a list table
    lstTable.append(row)

toDo_file.close() # close file to remove file lock

# Display the contents of the list to the user
print("Current To Do List\n")
print("Task" + "\t\t" + "Priority") # Spaced out for clarity here; can be shortened
for i,v in lstTable:                # loop through table and print contents
    print(i + "\t" + v)

input("\nPress enter for more options.")

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Current To Do List\n")
        print("Task\t\tPriority") #shortened from previous
        for i,v in lstTable:
            print(i + "\t" + v)
        input("\nPress enter to return to main menu.")
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        # Prompt user for a task and a priority
        strTaskAdd      = input("What is the task you would like to add? ")
        strPriorityAdd  = input("What is the new task's priority? ")
        lstTable.append((strTaskAdd,strPriorityAdd)) # append list with user inputs
        continue
    # Step 5 - Remove an existing item from the list/Table
    elif(strChoice == '3'):
        strDeleteChoice = input("Which item would you like to delete? ") # prompt user for desired delete item
        itemFound = False
        for row in lstTable:        # cycle through rows in table to find the item
            if strDeleteChoice in row:  # if item found - delete item and notify user of changes
                itemFound = True        # update itemFound Boolean
                lstTable.remove(row)    
                print(strDeleteChoice + " was removed from the list.\n")
                input("Press enter to return to the main menu.")
        if itemFound:                   # item not found - notify user
            pass # could not get "if !itemFound" to work, so made "if itemFound" do nothing
        else:
            print(strDeleteChoice + " was not found in the to do list. No changes were made.\n")
            input("Press enter to return to the main menu.")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        toDo_file = open(objFileName,'w')
        for i,v in lstTable:
            strData = i+","+v+"\n"
            toDo_file.write(strData)
        print("File updated.")
        toDo_file.close()
        input("Press enter to return to the main menu.")
        continue
    elif (strChoice == '5'):
        break #and Exit the program

