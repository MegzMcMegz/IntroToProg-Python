#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Megan J Hurt, 8/13/18, Added code to complete assignment 5
#   Megan J Hurt, 8/20/18, Edited existing code to complete assignment 6
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all to do items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove an existing item from the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

# -- Data --
objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []


# -- Processing code --
def DisplayContents():
    """ Display the current contents of the to do list """
    print("Current To Do List\n")
    print("Task" + "\t\t" + "Priority")
    for row in lstTable:  # loop through table and print contents
        print(row["Task"] + "\t" + row["Priority"])


def AddItem(strTask, strPriority):
    """
    :Desc : Takes two parameters (strTask and strPriority) and uses them to add a dictionary element to the list
    :param strTask: task to be added to table (string)
    :param strPriority: priority of task to be added to table (string)
    :return: none (table is updated within function)
    """
    dicRow = {"Task": strTask, "Priority": strPriority}
    lstTable.append(dicRow)  # append list with user inputs


def DeleteItem(strDeleteItem):
    """
    :Desc : Takes one parameter (strDeleteItem) and searches the list for a matching element. If found the element is
            removed and the user is notified. If the item is not found, the user is notified that no changes were
            made
    :param strDeleteItem: task to be deleted from table (string)
    :return: none (table is updated if item found; table is not updated if item not found)
    """
    itemFound = False  # local variable - boolean flag
    intRowNumber = 0   # local variable - sentry variable
    while intRowNumber < len(lstTable):
        if strDeleteItem == str(list(dict(lstTable[intRowNumber]).values())[0]):
            del lstTable[intRowNumber]
            itemFound = True  # item was found - update boolean flag
        intRowNumber += 1  # update sentry variable
    if itemFound:  # if the item wasn't found - need to notify user
        print(strDeleteItem + " was deleted from the to do list.")
    else:
        print(strDeleteItem + " was not found in the to do list. No changes were made.\n")
        input("Press enter to return to the main menu.")


def SaveData():
    """ Saves the current to do list to the Todo.txt file """
    toDo_file = open(objFileName, 'w')
    for dicRow in lstTable:
        toDo_file.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
    print("File updated.")
    toDo_file.close()
    input("Press enter to return to the main menu.")


def OpenTodoFile(file_parameter):
    """ Opens passed to do file and loads contents into a list """
    toDo_file = open(file_parameter, 'r')
    for row in toDo_file:                   # load each "row" of data from Todo.txt into dicRow
        strData = row.split(",")
        dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
        lstTable.append(dicRow)
    toDo_file.close()                       # close file


def DisplayMenu():
    """ Displays menu of options """
    while True:
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()  # adding a new line

        # Step 3 -Show the current items in the table
        if strChoice.strip() == '1':
            DisplayContents()  # call function DisplayContents() that displays table contents to user
            input("Press enter to return to main menu.")
            continue
        # Step 4 - Add a new item to the list/Table
        elif strChoice.strip() == '2':
            # Prompt user for a task and a priority
            strTaskAdd      = input("What is the task you would like to add? ")
            strPriorityAdd  = input("What is the new task's priority? ")
            AddItem(strTaskAdd, strPriorityAdd)  # call function AddItem that appends table with user inputs
            continue
        # Step 5 - Remove an existing item from the list/Table
        elif strChoice == '3':
            strDeleteChoice = input("Which task would you like to delete? ")  # prompt user for desired delete item
            DeleteItem(strDeleteChoice)
            continue
        # Step 6 - Save tasks to the ToDo.txt file
        elif strChoice == '4':
            SaveData()
            continue
        elif strChoice == '5':
            break  # Exit the program


# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add each dictionary "row" to a python list "table"
print("Opening To Do list . . .\n")
OpenTodoFile(objFileName)


# Display the contents of the list to the user
DisplayContents()

input("\nPress enter for more options.")

# Step 2 - Display a menu of choices to the user
DisplayMenu()

